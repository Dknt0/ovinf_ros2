#include "bitbot_cifx/device/imu_mti300.h"
#include <Eigen/Core>
#include <Eigen/Geometry>

#include <iostream>
namespace bitbot {
namespace {
constexpr struct Mti300ReceiveAddr {
  uint16_t roll = 0;
  uint16_t pitch = 4;
  uint16_t yaw = 8;
  uint16_t a_x = 12;
  uint16_t a_y = 16;
  uint16_t a_z = 20;
  uint16_t w_x = 24;
  uint16_t w_y = 28;
  uint16_t w_z = 32;
} mti300_receive_addr;
}  // namespace

ImuMti300::ImuMti300(const pugi::xml_node& imu_node) : CifxImu(imu_node) {
  basic_type_ = static_cast<uint32_t>(BasicDeviceType::IMU);
  type_ = static_cast<uint32_t>(CifxDeviceType::IMU_XSENSE_MTI300);
  input_data_length_ = 36;
  output_data_length_ = 2;
}

void Rot2RPY(Eigen::Matrix3f const& rot_mat, Eigen::Vector3f& res) {
  constexpr int row_num = 3;
  float roll_ = std::atan2(rot_mat(2, 1), rot_mat(2, 2));
  float pitch_ = std::atan2(
      -rot_mat(2, 0),
      sqrt(rot_mat(2, 1) * rot_mat(2, 1) + rot_mat(2, 2) * rot_mat(2, 2)));
  float yaw_ = std::atan2(rot_mat(1, 0), rot_mat(0, 0));
  res << roll_, pitch_, yaw_;
}

/**
 * @brief TODO: Write Rbi in config file
 *
 * @param[in] bus_data I don't care
 */
void ImuMti300::Input(void* bus_data) {
  std::memcpy(bus_receive_data_.data(), bus_data, 36);

  /*Eigen::Matrix3f Rwwf;*/
  /*Rwwf << -1., 0., 0., 0., -1., .0, .0, 0., 1.;*/
  Eigen::Matrix3f Rbi;
  // Imu frame w.r.t. body
  // Rbi << -1, 0, 0, 0, 1, 0, 0, 0, -1;
  Rbi << 1, 0, 0, 0, -1, 0, 0, 0, -1;
  std::memcpy(&imu_data_.runtime.roll,
              &bus_receive_data_[mti300_receive_addr.roll], sizeof(float));
  std::memcpy(&imu_data_.runtime.pitch,
              &bus_receive_data_[mti300_receive_addr.pitch], sizeof(float));
  std::memcpy(&imu_data_.runtime.yaw,
              &bus_receive_data_[mti300_receive_addr.yaw], sizeof(float));

  Eigen::Matrix3f Rwi;
  Eigen::AngleAxisf roll(imu_data_.runtime.roll / 180. * M_PI,
                         Eigen::Vector3f::UnitX());
  Eigen::AngleAxisf pitch(imu_data_.runtime.pitch / 180. * M_PI,
                          Eigen::Vector3f::UnitY());
  Eigen::AngleAxisf yaw(imu_data_.runtime.yaw / 180. * M_PI,
                        Eigen::Vector3f::UnitZ());
  /*std::cout << "original rpy: " << imu_data_.runtime.roll << " "*/
  /*          << imu_data_.runtime.pitch << " " << imu_data_.runtime.yaw*/
  /*          << std::endl;*/
  Rwi = yaw * pitch * roll;
  Eigen::Matrix3f Rwb = Rwi * Rbi.transpose();
  Eigen::Vector3f rpy_true;
  Rot2RPY(Rwb, rpy_true);
  imu_data_.runtime.roll = rpy_true(0) / M_PI * 180.;
  imu_data_.runtime.pitch = rpy_true(1) / M_PI * 180.;
  imu_data_.runtime.yaw = rpy_true(2) / M_PI * 180.;

  std::memcpy(&imu_data_.runtime.a_x,
              &bus_receive_data_[mti300_receive_addr.a_x], sizeof(float));
  std::memcpy(&imu_data_.runtime.a_y,
              &bus_receive_data_[mti300_receive_addr.a_y], sizeof(float));
  std::memcpy(&imu_data_.runtime.a_z,
              &bus_receive_data_[mti300_receive_addr.a_z], sizeof(float));

  Eigen::Vector3f a_i(imu_data_.runtime.a_x, imu_data_.runtime.a_y,
                      imu_data_.runtime.a_z);
  Eigen::Vector3f a_b = Rbi * a_i;
  imu_data_.runtime.a_x = a_b(0);
  imu_data_.runtime.a_y = a_b(1);
  imu_data_.runtime.a_z = a_b(2);

  std::memcpy(&imu_data_.runtime.w_x,
              &bus_receive_data_[mti300_receive_addr.w_x], sizeof(float));
  std::memcpy(&imu_data_.runtime.w_y,
              &bus_receive_data_[mti300_receive_addr.w_y], sizeof(float));
  std::memcpy(&imu_data_.runtime.w_z,
              &bus_receive_data_[mti300_receive_addr.w_z], sizeof(float));

  Eigen::Vector3f w_i(imu_data_.runtime.w_x, imu_data_.runtime.w_y,
                      imu_data_.runtime.w_z);
  Eigen::Vector3f w_b = Rbi * w_i;
  imu_data_.runtime.w_x = w_b(0);
  imu_data_.runtime.w_y = w_b(1);
  imu_data_.runtime.w_z = w_b(2);
}

void* ImuMti300::Output() { return &bus_send_data_; }

void ImuMti300::UpdateRuntimeData() {
  monitor_data_[0] = imu_data_.runtime.roll;
  monitor_data_[1] = imu_data_.runtime.pitch;
  monitor_data_[2] = imu_data_.runtime.yaw;
  monitor_data_[3] = imu_data_.runtime.a_x;
  monitor_data_[4] = imu_data_.runtime.a_y;
  monitor_data_[5] = imu_data_.runtime.a_z;
  monitor_data_[6] = imu_data_.runtime.w_x;
  monitor_data_[7] = imu_data_.runtime.w_y;
  monitor_data_[8] = imu_data_.runtime.w_z;
}

}  // namespace bitbot

